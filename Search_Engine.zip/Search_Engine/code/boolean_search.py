import pandas as pd
import argparse
import pickle
import nltk
import os
from nltk.corpus import stopwords

nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)
nltk.download('stopwords', quiet=True)

def tokenize(text):
    text = text.lower()
    words = nltk.word_tokenize(text)
    return words

def build_posting_list():
    stop_words = set(stopwords.words('english'))
    review_df = pd.read_pickle("reviews_segment.pkl")
    posting_list = {}

    for index, row in review_df.iterrows():
        review_id = str(row['review_id']).strip().strip("'\"")
        review_text = str(row['review_text']).lower()
        words = tokenize(review_text)
        #Uses NLTK stopwords list
        words = [word for word in words if word.isalnum() and word not in stop_words]
        for word in words:
            if word not in posting_list:
                posting_list[word] = set()
            posting_list[word].add(review_id)

    # Remove terms that appear in fewer than five documents
    posting_list = {term: ids for term, ids in posting_list.items() if len(ids) >= 5}
    with open('posting_list.pkl', 'wb') as f:
        pickle.dump(posting_list, f)
    return posting_list

def load_posting_list():
    with open('posting_list.pkl', 'rb') as f:
        posting_list = pickle.load(f)
    return posting_list

#Baseline boolean search using AND on everything
def baseline(args, posting_list):
    aspect1_tokens = tokenize(args.aspect1.lower())
    tokens_aspect1_opinion = aspect1_tokens + tokenize(args.opinion.lower())
    review_ids_aspect1_opinion = set.intersection(*(posting_list.get(token, set()) for token in tokens_aspect1_opinion))

    aspect2_tokens = tokenize(args.aspect2.lower())
    tokens_aspect2_opinion = aspect2_tokens + tokenize(args.opinion.lower())

    review_ids_aspect2_opinion = set.intersection(*(posting_list.get(token, set()) for token in tokens_aspect2_opinion))
    result_review_ids = review_ids_aspect1_opinion.intersection(review_ids_aspect2_opinion)

    result_review_ids = sorted(result_review_ids)
    return result_review_ids

#Loads Minqing Hu and Bing Liu list of postive and negative words
def load_opinion_lexicon(positive_file, negative_file):
    positive_words = set()
    negative_words = set()
    with open(positive_file, 'r', encoding='latin-1') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith(';'):
                positive_words.add(line)
    with open(negative_file, 'r', encoding='latin-1') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith(';'):
                negative_words.add(line)
    return positive_words, negative_words

def boolean_and_rating_search(args, posting_list):
    positive_words, negative_words = load_opinion_lexicon('positive-words.txt', 'negative-words.txt')
    opinion_tokens = tokenize(args.opinion.lower())
    # Determine the polarity of the opinion
    positive_count = sum(1 for token in opinion_tokens if token in positive_words)
    negative_count = sum(1 for token in opinion_tokens if token in negative_words)

    if positive_count > negative_count:
        opinion_polarity = 'positive'
    elif negative_count > positive_count:
        opinion_polarity = 'negative'
    else:
        # Default to positive if counts are equal or zero
        opinion_polarity = 'positive'

    aspect1_tokens = tokenize(args.aspect1.lower())
    tokens_aspect1_opinion = aspect1_tokens + opinion_tokens
    aspect2_tokens = tokenize(args.aspect2.lower())
    tokens_aspect2_opinion = aspect2_tokens + opinion_tokens

    review_ids_aspect1_opinion = set.intersection(*(posting_list.get(token, set()) for token in tokens_aspect1_opinion))
    review_ids_aspect2_opinion = set.intersection(*(posting_list.get(token, set()) for token in tokens_aspect2_opinion))
    result_review_ids = review_ids_aspect1_opinion.intersection(review_ids_aspect2_opinion)

    review_df = pd.read_pickle("reviews_segment.pkl")
    review_df['review_id'] = review_df['review_id'].astype(str).str.strip().str.strip("'\"")
    review_df['customer_review_rating'] = pd.to_numeric(review_df['customer_review_rating'], errors='coerce')
    review_df = review_df.dropna(subset=['customer_review_rating'])

    filtered_reviews = review_df[review_df['review_id'].isin(result_review_ids)]

    if opinion_polarity == 'positive':
        # Keep reviews with rating > 3
        filtered_reviews = filtered_reviews[filtered_reviews['customer_review_rating'] > 3]
    elif opinion_polarity == 'negative':
        # Keep reviews with rating <= 3
        filtered_reviews = filtered_reviews[filtered_reviews['customer_review_rating'] <= 3]
    else:
        pass

    result_review_ids = filtered_reviews['review_id'].tolist()
    result_review_ids = sorted(result_review_ids)
    return result_review_ids

def grammar_with_opinion_orientation(args, posting_list):
    aspect1_tokens = tokenize(args.aspect1.lower())
    aspect2_tokens = tokenize(args.aspect2.lower())
    aspect_tokens = aspect1_tokens + aspect2_tokens
    opinion_tokens = tokenize(args.opinion.lower())

    if aspect_tokens:
        review_ids_aspects = set.intersection(*(posting_list.get(token, set()) for token in aspect_tokens))
    else:
        review_ids_aspects = set()

    review_df = pd.read_pickle("reviews_segment.pkl")
    review_df['review_id'] = review_df['review_id'].astype(str).str.strip().str.strip("'\"")
    reviews_with_aspects = review_df[review_df['review_id'].isin(review_ids_aspects)]
    result_review_ids = set()

    for _, row in reviews_with_aspects.iterrows():
        review_id = row['review_id']
        review_text = str(row['review_text']).lower()
        sentences = nltk.sent_tokenize(review_text)
        # Check each sentence for co-occurrence of aspect and opinion terms
        for sentence in sentences:
            sentence_tokens = tokenize(sentence)
            if (set(aspect_tokens).intersection(sentence_tokens) and
                set(opinion_tokens).intersection(sentence_tokens)):
                result_review_ids.add(review_id)
                break  # No need to check other sentences in this review

    result_review_ids = sorted(result_review_ids)
    return result_review_ids

def main():
    parser = argparse.ArgumentParser(description="Perform the Boolean search.")
    parser.add_argument("-a1", "--aspect1", type=str, required=True, help="First word of the aspect")
    parser.add_argument("-a2", "--aspect2", type=str, required=True, help="Second word of the aspect")
    parser.add_argument("-o", "--opinion", type=str, required=True, help="Opinion word or phrase")
    parser.add_argument("-m", "--method", type=str, required=True, help="The method of Boolean operation: baseline, BooleanRatingSearch, and OpinionOrientated")
    args = parser.parse_args()

    try:
        posting_list = load_posting_list()
    except FileNotFoundError:
        print("Building the posting list")
        build_posting_list()
        posting_list = load_posting_list()

    method = args.method.lower()

    if method == "baseline":
        result_review_ids = baseline(args, posting_list)
    elif method == "booleanratingsearch":
        result_review_ids = boolean_and_rating_search(args, posting_list)
    elif method == "opinionorientation":
        result_review_ids = grammar_with_opinion_orientation(args, posting_list)
    else:
        print("\n!! Invalid Method !!\n")
        return

    revs = pd.DataFrame()
    revs["review_id"] = result_review_ids

    code_folder = os.path.dirname(os.path.abspath(__file__))
    parent_folder = os.path.dirname(code_folder)
    output_folder = os.path.join(parent_folder, "output")

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    opinion_filename = args.opinion.replace(' ', '_')
    output_filename = f"{args.aspect1}_{args.aspect2}_{opinion_filename}_{args.method}.pkl"
    output_path = os.path.join(output_folder, output_filename)

    revs.to_pickle(output_path)
    print(f"Results saved to {output_path}")

if __name__ == "__main__":
    main()
